class Chant < ApplicationRecord

end
